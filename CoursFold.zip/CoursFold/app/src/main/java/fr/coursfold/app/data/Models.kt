package fr.coursfold.app.data

import org.json.JSONArray
import org.json.JSONObject

/** Un morceau de phrase transcrit, avec le moment où il a été dit (ms depuis le début du cours). */
data class Segment(val atMs: Long, val text: String)

/** Une question détectée (ou posée par toi) et la réponse trouvée. */
data class QA(
    val atMs: Long,
    val question: String,
    val answer: String,
    val sources: List<Source> = emptyList(),
    val pending: Boolean = false,
    val error: Boolean = false,
)

data class Source(val title: String, val url: String)

/** Un cours enregistré. */
data class Session(
    val id: String,
    val subject: String,
    val startedAt: Long,
    val durationMs: Long = 0,
    val segments: List<Segment> = emptyList(),
    val qas: List<QA> = emptyList(),
    val summary: String = "",
    val course: String = "",
) {
    val fullText: String get() = segments.joinToString(" ") { it.text }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("subject", subject)
        put("startedAt", startedAt)
        put("durationMs", durationMs)
        put("segments", JSONArray().apply {
            segments.forEach { put(JSONObject().put("t", it.atMs).put("x", it.text)) }
        })
        put("qas", JSONArray().apply {
            qas.filter { !it.pending }.forEach { qa ->
                put(JSONObject().apply {
                    put("t", qa.atMs)
                    put("q", qa.question)
                    put("a", qa.answer)
                    put("e", qa.error)
                    put("s", JSONArray().apply {
                        qa.sources.forEach { put(JSONObject().put("title", it.title).put("url", it.url)) }
                    })
                })
            }
        })
        put("summary", summary)
        put("course", course)
    }

    companion object {
        fun fromJson(o: JSONObject): Session {
            val segs = o.optJSONArray("segments") ?: JSONArray()
            val qas = o.optJSONArray("qas") ?: JSONArray()
            return Session(
                id = o.getString("id"),
                subject = o.optString("subject", "Cours"),
                startedAt = o.optLong("startedAt"),
                durationMs = o.optLong("durationMs"),
                segments = (0 until segs.length()).map {
                    val s = segs.getJSONObject(it)
                    Segment(s.optLong("t"), s.optString("x"))
                },
                qas = (0 until qas.length()).map {
                    val q = qas.getJSONObject(it)
                    val src = q.optJSONArray("s") ?: JSONArray()
                    QA(
                        atMs = q.optLong("t"),
                        question = q.optString("q"),
                        answer = q.optString("a"),
                        error = q.optBoolean("e"),
                        sources = (0 until src.length()).map { i ->
                            val s = src.getJSONObject(i)
                            Source(s.optString("title"), s.optString("url"))
                        },
                    )
                },
                summary = o.optString("summary"),
                course = o.optString("course"),
            )
        }
    }
}
