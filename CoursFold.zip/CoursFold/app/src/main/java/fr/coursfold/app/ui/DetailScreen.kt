@file:OptIn(ExperimentalMaterial3Api::class)

package fr.coursfold.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import fr.coursfold.app.data.Session

@Composable
fun DetailScreen(vm: AppViewModel, id: String) {
    val s = vm.session(id) ?: run {
        LaunchedEffect(id) { vm.open(Screen.Home) }
        return
    }
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val ctx = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    val generating = vm.generatingId == id

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(s.subject, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { vm.open(Screen.Home) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { copy(ctx, vm.exportText(id)); vm.message = "Copié !" }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copier")
                    }
                    IconButton(onClick = { share(ctx, s.subject, vm.exportText(id)) }) {
                        Icon(Icons.Default.Share, contentDescription = "Partager")
                    }
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Supprimer")
                    }
                },
            )
        },
    ) { pad ->
        if (wide) {
            // Fold ouvert : le cours à gauche, le reste à droite.
            Row(Modifier.fillMaxSize().padding(pad)) {
                Column(Modifier.weight(0.55f).fillMaxHeight()) {
                    CourseTab(vm, s, generating)
                }
                VerticalDivider()
                Column(Modifier.weight(0.45f).fillMaxHeight()) {
                    Tabs(vm, s, generating, listOf("Résumé", "Questions", "Transcription"))
                }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(pad)) {
                Tabs(vm, s, generating, listOf("Cours", "Résumé", "Questions", "Transcription"))
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer ce cours ?") },
            text = { Text("La transcription, le résumé et le cours seront effacés du téléphone.") },
            confirmButton = {
                Button(onClick = { confirmDelete = false; vm.deleteSession(id) }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun Tabs(vm: AppViewModel, s: Session, generating: Boolean, titles: List<String>) {
    var tab by remember { mutableIntStateOf(0) }
    if (tab >= titles.size) tab = 0
    TabRow(selectedTabIndex = tab) {
        titles.forEachIndexed { i, t ->
            Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, maxLines = 1) })
        }
    }
    when (titles[tab]) {
        "Cours" -> CourseTab(vm, s, generating)
        "Résumé" -> Scrollable {
            when {
                s.summary.isNotBlank() -> MarkdownText(s.summary)
                generating -> Generating(vm.generatingStep)
                else -> Text("Pas encore de résumé.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        "Questions" -> Scrollable {
            if (s.qas.isEmpty()) {
                Text("Aucune question pendant ce cours.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { s.qas.forEach { QaCard(it) } }
            }
        }
        else -> Scrollable {
            SelectionContainer {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    s.segments.forEach { seg ->
                        Text(
                            formatDuration(seg.atMs) + "   " + seg.text,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CourseTab(vm: AppViewModel, s: Session, generating: Boolean) {
    Scrollable {
        when {
            generating && s.course.isBlank() -> Generating(vm.generatingStep)
            s.course.isNotBlank() -> {
                MarkdownText(s.course)
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { vm.generateCourse(s.id) }, enabled = !generating) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Text(if (generating) "  Génération…" else "  Régénérer")
                }
            }
            else -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Le cours propre n'a pas encore été généré.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = { vm.generateCourse(s.id) }) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Text("  Générer le résumé et le cours")
                }
            }
        }
    }
}

@Composable
private fun Generating(step: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 24.dp)) {
        CircularProgressIndicator()
        Text("   " + step.ifBlank { "Rédaction du cours…" })
    }
}

@Composable
private fun Scrollable(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(Modifier.widthIn(max = 760.dp).fillMaxWidth()) { content() }
    }
}

private fun copy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Cours", text))
}

private fun share(ctx: Context, subject: String, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Cours de $subject")
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(send, "Envoyer le cours vers…"))
}
