package fr.coursfold.app.speech

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Écoute le micro en continu et fait trois choses en même temps :
 *  1. affiche une transcription approximative en direct (Vosk, hors ligne) ;
 *  2. enregistre le cours en audio compressé (AAC, ~14 Mo/heure) pour que Gemini
 *     le retranscrive proprement à la fin ;
 *  3. garde les 90 dernières secondes en mémoire pour le bouton « question du prof ».
 */
class CourseRecorder(
    private val model: Model,
    private val audioFile: File,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onError: (String) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var thread: Thread? = null

    // Mémoire tampon circulaire des dernières secondes (PCM 16 bits).
    private val ring = ShortArray(SAMPLE_RATE * RING_SECONDS)
    private var ringPos = 0
    private var ringFilled = 0
    private val ringLock = Any()

    @SuppressLint("MissingPermission") // la permission micro est vérifiée avant le démarrage
    fun start(): Boolean {
        if (running) return true
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, SAMPLE_RATE * 2),
            )
        } catch (e: Exception) {
            onError("Micro indisponible : ${e.message}"); return false
        }
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            onError("Micro indisponible (déjà utilisé par une autre appli ?)")
            return false
        }
        val recognizer = try { Recognizer(model, SAMPLE_RATE.toFloat()) } catch (e: Exception) {
            record.release(); onError("Moteur vocal : ${e.message}"); return false
        }
        val encoder = try { AacWriter(audioFile) } catch (e: Exception) {
            null // si l'encodeur échoue, on garde au moins la transcription en direct
        }

        running = true
        thread = Thread({
            val buf = ShortArray(SAMPLE_RATE / 5) // 0,2 s
            try {
                record.startRecording()
                while (running) {
                    val n = record.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    pushRing(buf, n)
                    encoder?.write(buf, n)
                    if (recognizer.acceptWaveForm(buf, n)) {
                        val t = field(recognizer.result, "text")
                        main.post { onPartial(""); if (t.isNotBlank()) onFinal(t) }
                    } else {
                        val p = field(recognizer.partialResult, "partial")
                        main.post { onPartial(p) }
                    }
                }
                val last = field(recognizer.finalResult, "text")
                main.post { onPartial(""); if (last.isNotBlank()) onFinal(last) }
            } catch (e: Exception) {
                main.post { onError("Erreur micro : ${e.message}") }
            } finally {
                runCatching { record.stop() }
                record.release()
                runCatching { encoder?.close() }
            }
        }, "CourseRecorder")
        thread?.start()
        return true
    }

    fun stop() {
        running = false
        thread?.join(3000)
        thread = null
    }

    private fun pushRing(buf: ShortArray, n: Int) = synchronized(ringLock) {
        for (i in 0 until n) {
            ring[ringPos] = buf[i]
            ringPos = (ringPos + 1) % ring.size
        }
        ringFilled = minOf(ring.size, ringFilled + n)
    }

    /** Les dernières secondes d'audio au format WAV (pour les questions du prof). */
    fun recentWav(seconds: Int = RING_SECONDS): ByteArray? {
        val samples: ShortArray = synchronized(ringLock) {
            val count = minOf(ringFilled, seconds * SAMPLE_RATE)
            if (count < SAMPLE_RATE) return null // moins d'une seconde
            ShortArray(count) { i -> ring[(ringPos - count + i + ring.size) % ring.size] }
        }
        val pcm = ByteBuffer.allocate(samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        samples.forEach { pcm.putShort(it) }
        return wav(pcm.array())
    }

    private fun field(json: String?, key: String): String =
        runCatching { JSONObject(json ?: "{}").optString(key) }.getOrDefault("").trim()

    companion object {
        const val SAMPLE_RATE = 16000
        const val RING_SECONDS = 90

        fun wav(pcm: ByteArray): ByteArray {
            val out = ByteArrayOutputStream(pcm.size + 44)
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
            h.putInt(SAMPLE_RATE); h.putInt(SAMPLE_RATE * 2); h.putShort(2); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(pcm.size)
            out.write(h.array()); out.write(pcm)
            return out.toByteArray()
        }
    }
}

/**
 * Encode le son en AAC « ADTS » (.aac). Ce format peut être complété après une pause
 * et reste lisible même si l'appli est fermée brutalement.
 */
private class AacWriter(file: File) {
    private val out = FileOutputStream(file, true)
    private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    private val info = MediaCodec.BufferInfo()
    private var samplesIn = 0L

    init {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, CourseRecorder.SAMPLE_RATE, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 32_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
        }
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    fun write(pcm: ShortArray, n: Int) {
        val bytes = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) bytes.putShort(pcm[i])
        val data = bytes.array()
        var offset = 0
        while (offset < data.size) {
            val idx = codec.dequeueInputBuffer(20_000)
            if (idx < 0) { drain(false); continue }
            val input = codec.getInputBuffer(idx) ?: continue
            input.clear()
            val len = minOf(input.remaining(), data.size - offset)
            input.put(data, offset, len)
            val ptsUs = samplesIn * 1_000_000L / CourseRecorder.SAMPLE_RATE
            codec.queueInputBuffer(idx, 0, len, ptsUs, 0)
            samplesIn += len / 2
            offset += len
            drain(false)
        }
    }

    fun close() {
        try {
            val idx = codec.dequeueInputBuffer(50_000)
            if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, samplesIn * 1_000_000L / CourseRecorder.SAMPLE_RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
        } finally {
            runCatching { codec.stop() }
            codec.release()
            out.flush()
            out.close()
        }
    }

    private fun drain(endOfStream: Boolean) {
        var tries = 0
        while (true) {
            val idx = codec.dequeueOutputBuffer(info, if (endOfStream) 20_000 else 0)
            when {
                idx >= 0 -> {
                    val buf = codec.getOutputBuffer(idx)
                    val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (buf != null && info.size > 0 && !isConfig) {
                        val packet = ByteArray(info.size)
                        buf.position(info.offset)
                        buf.get(packet)
                        out.write(adtsHeader(packet.size))
                        out.write(packet)
                    }
                    codec.releaseOutputBuffer(idx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream || ++tries > 50) return
                }
                else -> Unit // changement de format : rien à faire en ADTS
            }
        }
    }

    /** En-tête ADTS : AAC-LC, 16 kHz, mono. */
    private fun adtsHeader(payload: Int): ByteArray {
        val len = payload + 7
        val profile = 2 // AAC LC
        val freqIdx = 8 // 16 000 Hz
        val chan = 1
        return byteArrayOf(
            0xFF.toByte(),
            0xF1.toByte(),
            (((profile - 1) shl 6) or (freqIdx shl 2) or (chan shr 2)).toByte(),
            (((chan and 3) shl 6) or (len shr 11)).toByte(),
            ((len and 0x7FF) shr 3).toByte(),
            (((len and 7) shl 5) or 0x1F).toByte(),
            0xFC.toByte(),
        )
    }
}
