package fr.coursfold.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Affiche le Markdown simple produit par l'IA (titres, listes, gras, italique). */
@Composable
fun MarkdownText(markdown: String, modifier: Modifier = Modifier) {
    SelectionContainer(modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            markdown.lines().forEach { raw ->
                val line = raw.trimEnd()
                val trimmed = line.trimStart()
                val indent = (line.length - trimmed.length) / 2
                when {
                    trimmed.isEmpty() -> Spacer(Modifier.height(4.dp))
                    trimmed.startsWith("### ") -> Text(
                        inline(trimmed.drop(4)),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    trimmed.startsWith("## ") -> Text(
                        inline(trimmed.drop(3)),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 10.dp),
                    )
                    trimmed.startsWith("# ") -> Text(
                        inline(trimmed.drop(2)),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp),
                    )
                    trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ") -> Row(
                        Modifier.padding(start = (12 * indent).dp)
                    ) {
                        Text("•", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(inline(trimmed.drop(2)), style = MaterialTheme.typography.bodyLarge)
                    }
                    trimmed == "---" || trimmed == "***" -> Spacer(Modifier.height(8.dp))
                    else -> Text(
                        inline(trimmed),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(start = (12 * indent).dp),
                    )
                }
            }
        }
    }
}

/** Gère **gras**, *italique* et `code` à l'intérieur d'une ligne. */
private fun inline(text: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        when {
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end > i) {
                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                    append(text.substring(i + 2, end))
                    pop()
                    i = end + 2
                } else { append("**"); i += 2 }
            }
            text[i] == '*' && i + 1 < text.length && text[i + 1] != ' ' -> {
                val end = text.indexOf('*', i + 1)
                if (end > i) {
                    pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                    append(text.substring(i + 1, end))
                    pop()
                    i = end + 1
                } else { append('*'); i++ }
            }
            text[i] == '`' -> {
                val end = text.indexOf('`', i + 1)
                if (end > i) {
                    pushStyle(SpanStyle(fontWeight = FontWeight.Medium))
                    append(text.substring(i + 1, end))
                    pop()
                    i = end + 1
                } else { append('`'); i++ }
            }
            else -> { append(text[i]); i++ }
        }
    }
}
