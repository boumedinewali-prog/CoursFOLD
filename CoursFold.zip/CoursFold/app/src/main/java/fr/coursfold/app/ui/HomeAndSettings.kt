@file:OptIn(ExperimentalMaterial3Api::class)

package fr.coursfold.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import fr.coursfold.app.data.Session
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private val dateFormat = SimpleDateFormat("EEE d MMM, HH:mm", Locale.FRANCE)

@Composable
fun HomeScreen(vm: AppViewModel, onStart: (String) -> Unit) {
    var subject by remember { mutableStateOf(vm.settings.lastSubject) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("CoursFold", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { vm.open(Screen.Settings) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Réglages")
                    }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item {
                Card(
                    modifier = Modifier.widthIn(max = 720.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Nouveau cours", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("Matière (ex. Histoire, Biologie…)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Button(onClick = { onStart(subject) }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                            Icon(Icons.Default.Mic, contentDescription = null)
                            Text("  Démarrer l'enregistrement", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
            if (vm.sessions.isEmpty()) {
                item {
                    Text(
                        "Tes cours apparaîtront ici.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp),
                    )
                }
            } else {
                item {
                    Text(
                        "Mes cours",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.widthIn(max = 720.dp).fillMaxWidth().padding(top = 8.dp),
                    )
                }
                items(vm.sessions, key = { it.id }) { s -> SessionRow(s) { vm.open(Screen.Detail(s.id)) } }
            }
        }
    }
}

@Composable
private fun SessionRow(s: Session, onClick: () -> Unit) {
    Card(Modifier.widthIn(max = 720.dp).fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.subject, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${dateFormat.format(Date(s.startedAt))} · ${formatDuration(s.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (s.course.isNotBlank()) {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = "Fiche prête",
                    tint = MaterialTheme.colorScheme.secondary,
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val st = vm.settings
    var key by remember { mutableStateOf(st.apiKey) }
    var model by remember { mutableStateOf(st.model) }
    var level by remember { mutableStateOf(st.level) }
    var auto by remember { mutableStateOf(st.autoQuestions) }
    var web by remember { mutableStateOf(st.webSearch) }
    var mute by remember { mutableStateOf(st.muteBeeps) }
    var engine by remember { mutableStateOf(st.engine) }
    val uri = LocalUriHandler.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Réglages") },
                navigationIcon = {
                    IconButton(onClick = { vm.open(Screen.Home) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(Modifier.widthIn(max = 640.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Clé Gemini (gratuite)", style = MaterialTheme.typography.titleMedium)
                Text(
                    "1. Ouvre Google AI Studio et connecte-toi avec ton compte Google.\n" +
                        "2. Appuie sur « Create API key ».\n" +
                        "3. Copie la clé et colle-la ci-dessous.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedButton(onClick = { uri.openUri("https://aistudio.google.com/apikey") }) {
                    Text("Ouvrir Google AI Studio")
                }
                OutlinedTextField(
                    value = key, onValueChange = { key = it },
                    label = { Text("Clé API") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = level, onValueChange = { level = it },
                    label = { Text("Ton niveau (ex. Terminale, L1 droit…)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                HorizontalDivider()
                Text("Transcription", style = MaterialTheme.typography.titleMedium)
                EngineOption(
                    "Continue hors ligne (recommandé)",
                    "Écoute sans couper et enregistre le son : Gemini réécoute le vrai audio pour les questions et pour rédiger le cours. Modèle de 41 Mo téléchargé au premier cours.",
                    engine == "vosk",
                ) { engine = "vosk" }
                EngineOption(
                    "Moteur vocal du téléphone",
                    "Sans enregistrement audio : le cours est rédigé à partir du texte seul, qui peut avoir des trous.",
                    engine == "google",
                ) { engine = "google" }

                HorizontalDivider()
                SwitchRow(
                    "Détecter les questions du prof automatiquement",
                    "Utilise plus de quota gratuit. Sinon, appuie sur le bouton quand le prof pose une question.",
                    auto,
                ) { auto = it }
                SwitchRow(
                    "Recherche Google pour les réponses",
                    "Réponses plus fiables, avec sources.",
                    web,
                ) { web = it }
                SwitchRow(
                    "Couper les bips pendant l'enregistrement",
                    "Coupe aussi la musique et les notifications le temps du cours.",
                    mute,
                ) { mute = it }

                HorizontalDivider()
                OutlinedTextField(
                    value = model, onValueChange = { model = it },
                    label = { Text("Modèle Gemini (avancé)") }, singleLine = true,
                    supportingText = { Text("Par défaut : gemini-2.5-flash") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Avec l'offre gratuite, Google peut utiliser ce que tu envoies pour améliorer ses produits, " +
                        "et le nombre de requêtes par jour est limité. Les enregistrements restent sur ton téléphone ; " +
                        "seul le texte est envoyé à Gemini.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = { vm.saveSettings(key, model, level, auto, web, mute, engine) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text("Enregistrer") }
            }
        }
    }
}

@Composable
private fun EngineOption(title: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
