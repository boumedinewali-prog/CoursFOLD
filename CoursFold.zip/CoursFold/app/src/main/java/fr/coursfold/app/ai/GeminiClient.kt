package fr.coursfold.app.ai

import fr.coursfold.app.data.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class AiResult(val text: String, val sources: List<Source>)

class AiException(message: String) : Exception(message)

/**
 * Appelle l'API Gemini de Google (offre gratuite avec une clé Google AI Studio).
 * Pas de bibliothèque externe : une simple requête HTTPS.
 */
class GeminiClient(
    private val apiKey: () -> String,
    private val model: () -> String,
    private val fallbackModel: String,
) {
    suspend fun generate(
        system: String,
        prompt: String,
        webSearch: Boolean,
        temperature: Double = 0.3,
    ): AiResult = withContext(Dispatchers.IO) {
        val key = apiKey()
        if (key.isBlank()) throw AiException("Ajoute ta clé Gemini gratuite dans les réglages (⚙️).")

        val models = listOf(model(), fallbackModel).distinct()
        var lastError: AiException? = null
        for (m in models) {
            // 1) avec recherche Google si demandé, 2) sans si la recherche est refusée
            val attempts = if (webSearch) listOf(true, false) else listOf(false)
            for (search in attempts) {
                try {
                    return@withContext call(key, m, system, prompt, search, temperature)
                } catch (e: HttpError) {
                    lastError = AiException(e.friendly())
                    when {
                        e.code == 400 && search -> continue          // recherche non dispo : on réessaie sans
                        e.code == 429 && search -> continue          // quota de recherche épuisé : sans recherche
                        e.code == 429 || e.code == 404 -> break      // quota du modèle ou modèle inconnu : modèle de secours
                        e.code >= 500 -> { delay(1500); continue }
                        else -> throw lastError!!
                    }
                }
            }
        }
        throw lastError ?: AiException("Erreur inconnue.")
    }

    private class HttpError(val code: Int, val body: String) : Exception() {
        fun friendly(): String {
            val apiMsg = runCatching {
                JSONObject(body).getJSONObject("error").optString("message")
            }.getOrDefault("")
            return when (code) {
                400 -> if (apiMsg.contains("API key", true)) "Clé API invalide : vérifie-la dans les réglages."
                       else "Requête refusée : $apiMsg"
                401, 403 -> "Clé API refusée : vérifie-la dans les réglages."
                404 -> "Modèle introuvable. Remets « gemini-2.5-flash » dans les réglages."
                429 -> "Quota gratuit du jour atteint. Réessaie plus tard (il se recharge chaque jour)."
                else -> "Erreur du serveur Gemini ($code). Réessaie dans un instant."
            }
        }
    }

    private fun call(
        key: String,
        model: String,
        system: String,
        prompt: String,
        search: Boolean,
        temperature: Double,
    ): AiResult {
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            put("contents", JSONArray().put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            ))
            if (search) put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            put("generationConfig", JSONObject().put("temperature", temperature))
        }

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" +
            URLEncoder.encode(model, "UTF-8") + ":generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 120_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw HttpError(code, text)
            return parse(text)
        } catch (e: HttpError) {
            throw e
        } catch (e: java.io.IOException) {
            throw AiException("Pas de connexion internet (ou réseau de l'école bloqué).")
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(raw: String): AiResult {
        val json = JSONObject(raw)
        val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw AiException("Réponse vide de Gemini (contenu peut-être bloqué).")
        val parts = candidate.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        val text = buildString {
            for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
        }.trim()
        if (text.isEmpty()) throw AiException("Réponse vide de Gemini.")

        val sources = mutableListOf<Source>()
        val chunks = candidate.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        if (chunks != null) {
            for (i in 0 until chunks.length()) {
                val web = chunks.getJSONObject(i).optJSONObject("web") ?: continue
                val uri = web.optString("uri")
                if (uri.isNotBlank()) sources += Source(web.optString("title", uri), uri)
            }
        }
        return AiResult(text, sources.distinctBy { it.title }.take(4))
    }
}
