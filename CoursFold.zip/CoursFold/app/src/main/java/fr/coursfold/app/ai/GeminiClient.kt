package fr.coursfold.app.ai

import android.util.Base64
import fr.coursfold.app.data.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class AiResult(val text: String, val sources: List<Source>)

class AiException(message: String) : Exception(message)

/**
 * Appelle l'API Gemini de Google (offre gratuite avec une clé Google AI Studio).
 * Pas de bibliothèque externe : de simples requêtes HTTPS.
 */
class GeminiClient(
    private val apiKey: () -> String,
    private val model: () -> String,
    private val fallbackModel: String,
    /** Appelé quand l'appli a dû choisir elle-même un autre modèle (pour l'enregistrer). */
    private val onModelChanged: (String) -> Unit = {},
) {
    private val base = "https://generativelanguage.googleapis.com"

    // ---------- Fabriquer les morceaux d'une requête ----------

    fun textPart(text: String): JSONObject = JSONObject().put("text", text)

    fun inlineAudioPart(bytes: ByteArray, mime: String): JSONObject = JSONObject().put(
        "inline_data",
        JSONObject().put("mime_type", mime).put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)),
    )

    fun fileAudioPart(uri: String, mime: String): JSONObject = JSONObject().put(
        "file_data", JSONObject().put("mime_type", mime).put("file_uri", uri),
    )

    // ---------- Génération ----------

    suspend fun generate(
        system: String,
        prompt: String,
        webSearch: Boolean,
        temperature: Double = 0.3,
    ): AiResult = generate(system, listOf(textPart(prompt)), webSearch, temperature)

    suspend fun generate(
        system: String,
        parts: List<JSONObject>,
        webSearch: Boolean,
        temperature: Double = 0.3,
        timeoutMs: Int = 120_000,
    ): AiResult = withContext(Dispatchers.IO) {
        val key = key()
        val models = mutableListOf(model(), fallbackModel).distinct().toMutableList()
        var lastError: AiException? = null
        var discovered = false
        var i = 0
        while (i < models.size) {
            val m = models[i]
            val attempts = if (webSearch) listOf(true, false) else listOf(false)
            var nextModel = false
            for (search in attempts) {
                try {
                    val r = call(key, m, system, parts, search, temperature, timeoutMs)
                    if (m != model()) onModelChanged(m)
                    return@withContext r
                } catch (e: HttpError) {
                    lastError = AiException(e.friendly())
                    when {
                        e.code == 400 && e.isKeyProblem() -> throw lastError!!
                        (e.code == 400 || e.code == 429) && search -> continue // sans recherche Google
                        e.code == 404 || e.code == 429 || e.code == 400 -> { nextModel = true; break }
                        e.code >= 500 -> { delay(2000); continue }
                        else -> throw lastError!!
                    }
                }
            }
            // Modèle introuvable ou épuisé : on demande à Google la liste des modèles disponibles.
            if (nextModel && i == models.size - 1 && !discovered) {
                discovered = true
                runCatching { availableModels(key) }.getOrDefault(emptyList())
                    .filter { it !in models }
                    .take(3)
                    .forEach { models += it }
            }
            i++
        }
        throw lastError ?: AiException("Erreur inconnue.")
    }

    // ---------- Envoi d'un fichier audio (cours complet) ----------

    /** Envoie un fichier à Gemini et renvoie son adresse (utilisable ~48 h). */
    suspend fun uploadFile(file: File, mime: String, onProgress: (Float) -> Unit = {}): String =
        withContext(Dispatchers.IO) {
            val key = key()
            val size = file.length()

            // 1) On annonce l'envoi.
            val start = (URL("$base/upload/v1beta/files").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("x-goog-api-key", key)
                setRequestProperty("X-Goog-Upload-Protocol", "resumable")
                setRequestProperty("X-Goog-Upload-Command", "start")
                setRequestProperty("X-Goog-Upload-Header-Content-Length", size.toString())
                setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
                setRequestProperty("Content-Type", "application/json")
            }
            val uploadUrl = try {
                start.outputStream.use {
                    it.write(JSONObject().put("file", JSONObject().put("display_name", file.name)).toString().toByteArray())
                }
                val code = start.responseCode
                if (code !in 200..299) throw HttpError(code, readBody(start, false))
                start.getHeaderField("x-goog-upload-url") ?: throw AiException("Envoi refusé par Gemini.")
            } catch (e: HttpError) {
                throw AiException(e.friendly())
            } catch (e: java.io.IOException) {
                throw AiException("Pas de connexion internet pour envoyer l'audio.")
            } finally {
                start.disconnect()
            }

            // 2) On envoie le fichier.
            val up = (URL(uploadUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 300_000
                doOutput = true
                setFixedLengthStreamingMode(size)
                setRequestProperty("X-Goog-Upload-Offset", "0")
                setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
            }
            val info = try {
                up.outputStream.use { out ->
                    file.inputStream().use { input ->
                        val buf = ByteArray(256 * 1024)
                        var sent = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            sent += n
                            onProgress(sent.toFloat() / size)
                        }
                    }
                }
                val code = up.responseCode
                val body = readBody(up, code in 200..299)
                if (code !in 200..299) throw HttpError(code, body)
                JSONObject(body).getJSONObject("file")
            } catch (e: HttpError) {
                throw AiException(e.friendly())
            } catch (e: java.io.IOException) {
                throw AiException("L'envoi de l'audio a été coupé. Réessaie avec une bonne connexion.")
            } finally {
                up.disconnect()
            }

            // 3) On attend que Google ait fini de traiter le fichier.
            val name = info.getString("name")
            var state = info.optString("state")
            var waited = 0
            while (state == "PROCESSING" && waited < 180) {
                delay(3000); waited += 3
                state = runCatching {
                    JSONObject(get("$base/v1beta/$name", key)).optString("state")
                }.getOrDefault("PROCESSING")
            }
            if (state == "FAILED") throw AiException("Google n'a pas réussi à lire l'audio.")
            info.getString("uri")
        }

    // ---------- Détails techniques ----------

    private fun key(): String = apiKey().ifBlank {
        throw AiException("Ajoute ta clé Gemini gratuite dans les réglages (⚙️).")
    }

    private class HttpError(val code: Int, val body: String) : Exception() {
        val apiMsg: String = runCatching {
            JSONObject(body).getJSONObject("error").optString("message")
        }.getOrDefault("").take(300)

        fun isKeyProblem() = apiMsg.contains("API key", true) || apiMsg.contains("API_KEY", true)

        fun friendly(): String {
            val detail = if (apiMsg.isNotBlank()) "\n(Google : $apiMsg)" else ""
            return when {
                code == 400 && isKeyProblem() -> "Clé API invalide : recopie-la dans les réglages.$detail"
                code == 401 || code == 403 -> "Clé API refusée : vérifie-la dans les réglages.$detail"
                code == 404 -> "Modèle Gemini introuvable.$detail"
                code == 429 -> "Quota gratuit atteint, réessaie plus tard (il se recharge chaque jour).$detail"
                code >= 500 -> "Serveur Gemini indisponible ($code), réessaie dans un instant.$detail"
                else -> "Erreur Gemini ($code).$detail"
            }
        }
    }

    private fun readBody(conn: HttpURLConnection, ok: Boolean): String {
        val stream = if (ok) conn.inputStream else conn.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
    }

    private fun get(url: String, key: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            val code = conn.responseCode
            val body = readBody(conn, code in 200..299)
            if (code !in 200..299) throw HttpError(code, body)
            return body
        } finally {
            conn.disconnect()
        }
    }

    /** Les modèles « Flash » disponibles pour cette clé, du plus récent au plus ancien. */
    private fun availableModels(key: String): List<String> {
        val json = JSONObject(get("$base/v1beta/models?pageSize=200", key))
        val arr = json.optJSONArray("models") ?: return emptyList()
        val names = (0 until arr.length()).mapNotNull { idx ->
            val m = arr.getJSONObject(idx)
            val methods = m.optJSONArray("supportedGenerationMethods") ?: JSONArray()
            val canGenerate = (0 until methods.length()).any { methods.getString(it) == "generateContent" }
            val name = m.optString("name").removePrefix("models/")
            val bad = listOf("image", "tts", "live", "audio", "embedding", "robotics", "computer", "exp")
            if (canGenerate && name.contains("flash") && bad.none { name.contains(it) }) name else null
        }
        return names.sortedWith(
            compareBy<String> { it.contains("preview") }.thenByDescending { it }
        )
    }

    private fun call(
        key: String,
        model: String,
        system: String,
        parts: List<JSONObject>,
        search: Boolean,
        temperature: Double,
        timeoutMs: Int,
    ): AiResult {
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(textPart(system))))
            put("contents", JSONArray().put(
                JSONObject().put("role", "user").put("parts", JSONArray().apply { parts.forEach { put(it) } })
            ))
            if (search) put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            put("generationConfig", JSONObject().put("temperature", temperature))
        }

        val url = URL("$base/v1beta/models/" + URLEncoder.encode(model, "UTF-8") + ":generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = timeoutMs
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val text = readBody(conn, code in 200..299)
            if (code !in 200..299) throw HttpError(code, text)
            return parse(text)
        } catch (e: HttpError) {
            throw e
        } catch (e: AiException) {
            throw e
        } catch (e: java.net.SocketTimeoutException) {
            throw AiException("Gemini met trop de temps à répondre. Réessaie.")
        } catch (e: java.io.IOException) {
            throw AiException("Pas de connexion internet (ou réseau de l'école bloqué).")
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(raw: String): AiResult {
        val json = JSONObject(raw)
        val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw AiException("Réponse vide de Gemini (contenu peut-être bloqué).")
        val parts = candidate.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        val text = buildString {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought")) append(p.optString("text"))
            }
        }.trim()
        if (text.isEmpty()) throw AiException("Réponse vide de Gemini.")

        val sources = mutableListOf<Source>()
        val chunks = candidate.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        if (chunks != null) {
            for (i in 0 until chunks.length()) {
                val web = chunks.getJSONObject(i).optJSONObject("web") ?: continue
                val uri = web.optString("uri")
                if (uri.isNotBlank()) sources += Source(web.optString("title", uri), uri)
            }
        }
        return AiResult(text, sources.distinctBy { it.title }.take(4))
    }
}
