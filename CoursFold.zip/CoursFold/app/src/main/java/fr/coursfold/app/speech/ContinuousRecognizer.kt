package fr.coursfold.app.speech

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Reconnaissance vocale continue et gratuite, faite par le téléphone.
 *
 * Android écoute par « phrases » : à chaque pause, il rend le texte et s'arrête.
 * Cette classe le relance aussitôt, en boucle, pour couvrir tout le cours.
 * Elle essaie d'abord la reconnaissance 100 % sur l'appareil (hors ligne),
 * puis bascule sur le moteur standard si le français n'y est pas installé.
 *
 * À utiliser uniquement depuis le thread principal.
 */
class ContinuousRecognizer(
    private val context: Context,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onFatal: (String) -> Unit,
) {
    private val handler = Handler(Looper.getMainLooper())
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var useOnDevice = true
    private var mutedStreams = emptyList<Int>()
    private var consecutiveErrors = 0
    private var lastPartial = ""

    /** Si le moteur coupe avant de rendre sa phrase, on garde quand même le texte déjà entendu. */
    private fun flushPartial() {
        val t = lastPartial.trim()
        lastPartial = ""
        onPartial("")
        if (t.isNotEmpty()) onFinal(t)
    }

    var muteBeeps: Boolean = true

    val isRunning: Boolean get() = running

    fun start() {
        if (running) return
        if (!SpeechRecognizer.isRecognitionAvailable(context) &&
            !SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        ) {
            onFatal("Aucun service de reconnaissance vocale trouvé. Installe ou mets à jour l'appli « Google » ou « Speech Services by Google » depuis le Play Store.")
            return
        }
        running = true
        consecutiveErrors = 0
        handler.removeCallbacksAndMessages(null) // annule un éventuel « remettre le son » en attente
        if (muteBeeps && mutedStreams.isEmpty()) muteSystemSounds()
        useOnDevice = SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        createRecognizer()
        listen()
    }

    fun stop() {
        if (running) flushPartial()
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.let {
            runCatching { it.stopListening() }
            runCatching { it.destroy() }
        }
        recognizer = null
        // On laisse le temps au dernier « bip » éventuel avant de remettre le son.
        handler.postDelayed({ unmuteSystemSounds() }, 600)
        onPartial("")
    }

    private fun createRecognizer() {
        recognizer?.let { runCatching { it.destroy() } }
        val r = if (useOnDevice) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }
        r.setRecognitionListener(listener)
        recognizer = r
        onStatus(if (useOnDevice) "Écoute (hors ligne, sur le téléphone)" else "Écoute (moteur Google)")
    }

    private fun buildIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        // On demande au moteur d'attendre des pauses plus longues avant de couper.
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
    }

    private fun listen() {
        if (!running) return
        val r = recognizer ?: return
        runCatching { r.startListening(buildIntent()) }
            .onFailure { restart(delayMs = 500, recreate = true) }
    }

    private fun restart(delayMs: Long = 0, recreate: Boolean = false) {
        if (!running) return
        handler.postDelayed({
            if (!running) return@postDelayed
            if (recreate) createRecognizer()
            listen()
        }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            if (text.isNotBlank()) {
                lastPartial = text
                onPartial(text)
            }
        }

        override fun onResults(results: Bundle?) {
            consecutiveErrors = 0
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            val heard = text.ifBlank { lastPartial }.trim()
            lastPartial = ""
            onPartial("")
            if (heard.isNotEmpty()) onFinal(heard)
            restart()
        }

        override fun onError(error: Int) {
            if (!running) return
            flushPartial()
            when (error) {
                // Silence ou rien compris : on relance simplement.
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart()

                // Le français n'est pas dispo hors ligne : on passe au moteur standard.
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                    if (useOnDevice) {
                        useOnDevice = false
                        restart(delayMs = 200, recreate = true)
                    } else {
                        stop()
                        onFatal("Le français n'est pas disponible pour la reconnaissance vocale. Va dans Paramètres > Gestion globale > Langue et saisie > Reconnaissance vocale, et télécharge le pack Français.")
                    }
                }

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    stop()
                    onFatal("L'appli n'a pas accès au micro.")
                }

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restart(delayMs = 800, recreate = true)

                else -> {
                    consecutiveErrors++
                    if (consecutiveErrors >= 3 && useOnDevice) {
                        // Le moteur hors ligne plante en boucle : on essaie l'autre.
                        useOnDevice = false
                        consecutiveErrors = 0
                        restart(delayMs = 300, recreate = true)
                    } else {
                        val wait = (500L * consecutiveErrors).coerceAtMost(5000L)
                        if (consecutiveErrors >= 3) onStatus("Reconnexion au service vocal…")
                        restart(delayMs = wait, recreate = true)
                    }
                }
            }
        }
    }

    // --- Couper les « bips » qu'Android joue à chaque relance de l'écoute ---

    private fun muteSystemSounds() {
        val streams = listOf(AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_MUSIC)
        mutedStreams = streams.filter { s ->
            runCatching {
                if (!audio.isStreamMute(s)) {
                    audio.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                    true
                } else false
            }.getOrDefault(false)
        }
    }

    private fun unmuteSystemSounds() {
        mutedStreams.forEach { s ->
            runCatching { audio.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) }
        }
        mutedStreams = emptyList()
    }
}
