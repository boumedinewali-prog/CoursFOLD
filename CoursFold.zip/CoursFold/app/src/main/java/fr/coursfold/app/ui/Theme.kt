package fr.coursfold.app.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val Light = lightColorScheme(
    primary = Color(0xFF1F3A5F),
    secondary = Color(0xFFB8741A),
    tertiary = Color(0xFF2E7D5B),
)
private val Dark = darkColorScheme(
    primary = Color(0xFFA9C7F0),
    secondary = Color(0xFFF2B866),
    tertiary = Color(0xFF8FD3B2),
)

/** Reprend les couleurs de ton fond d'écran (Material You), comme le reste du Galaxy. */
@Composable
fun CoursTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
