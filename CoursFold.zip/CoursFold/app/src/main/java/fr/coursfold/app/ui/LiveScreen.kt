@file:OptIn(ExperimentalMaterial3Api::class)

package fr.coursfold.app.ui

import android.app.Activity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import fr.coursfold.app.data.QA

@Composable
fun LiveScreen(vm: AppViewModel) {
    val session = vm.live ?: return
    val wide = LocalConfiguration.current.screenWidthDp >= 600 // Fold ouvert
    var confirmEnd by remember { mutableStateOf(false) }

    // L'écran reste allumé pendant le cours (sinon Android coupe le micro).
    val activity = LocalContext.current as? Activity
    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(session.subject, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (vm.recording) {
                                Box(Modifier.size(8.dp).background(MaterialTheme.colorScheme.error, CircleShape))
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                formatDuration(vm.elapsedMs) + "  ·  " + vm.status,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { if (vm.recording) vm.pauseRecording() else vm.resumeRecording() }) {
                        Icon(
                            if (vm.recording) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (vm.recording) "Pause" else "Reprendre",
                        )
                    }
                    FilledTonalButton(onClick = { confirmEnd = true }, modifier = Modifier.padding(end = 8.dp)) {
                        Icon(Icons.Default.Stop, contentDescription = null)
                        Text(" Terminer")
                    }
                },
            )
        },
    ) { pad ->
        if (wide) {
            // Fold ouvert : transcription à gauche, réponses à droite.
            Row(Modifier.fillMaxSize().padding(pad)) {
                TranscriptPane(vm, Modifier.weight(0.58f).fillMaxHeight())
                AnswerPane(vm, session.qas, Modifier.weight(0.42f).fillMaxHeight().padding(start = 4.dp))
            }
        } else {
            // Fold fermé : transcription en haut, réponses en bas.
            Column(Modifier.fillMaxSize().padding(pad)) {
                TranscriptPane(vm, Modifier.weight(0.55f).fillMaxWidth())
                AnswerPane(vm, session.qas, Modifier.weight(0.45f).fillMaxWidth())
            }
        }
    }

    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("Terminer le cours ?") },
            text = { Text("L'enregistrement s'arrête et l'appli prépare le résumé et le cours propre.") },
            confirmButton = {
                Button(onClick = { confirmEnd = false; vm.finishCourse() }) { Text("Terminer") }
            },
            dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Continuer") } },
        )
    }
}

@Composable
private fun TranscriptPane(vm: AppViewModel, modifier: Modifier) {
    val segments = vm.live?.segments.orEmpty()
    val listState = rememberLazyListState()
    // Défile automatiquement vers le bas quand du texte arrive.
    LaunchedEffect(segments.size, vm.partial.length / 40) {
        val last = segments.size // l'élément « partiel » est à la fin
        listState.animateScrollToItem(last)
    }
    LazyColumn(
        state = listState,
        modifier = modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (segments.isEmpty() && vm.partial.isBlank()) {
            item {
                Text(
                    if (vm.recording) "J'écoute… Pose le téléphone près du prof." else "En pause.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 24.dp),
                )
            }
        }
        items(segments) { seg ->
            Row {
                Text(
                    formatDuration(seg.atMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(52.dp).padding(top = 4.dp),
                )
                Text(seg.text, style = MaterialTheme.typography.bodyLarge)
            }
        }
        item {
            if (vm.partial.isNotBlank()) {
                Text(
                    vm.partial,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 52.dp, bottom = 16.dp),
                )
            } else Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun AnswerPane(vm: AppViewModel, qas: List<QA>, modifier: Modifier) {
    var typed by remember { mutableStateOf("") }
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 2.dp,
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.askQuestion("") },
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                Icon(Icons.Default.Lightbulb, contentDescription = null)
                Text("  Le prof pose une question", style = MaterialTheme.typography.titleSmall)
            }
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                placeholder = { Text("Ou écris ta question…") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    if (typed.isNotBlank()) { vm.askQuestion(typed); typed = "" }
                }),
                trailingIcon = {
                    IconButton(onClick = { if (typed.isNotBlank()) { vm.askQuestion(typed); typed = "" } }) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Chercher")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(qas) { qa -> QaCard(qa) }
            }
        }
    }
}

@Composable
fun QaCard(qa: QA) {
    val uri = LocalUriHandler.current
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (qa.error) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.surface,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                formatDuration(qa.atMs) + "  ·  " + qa.question,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.SemiBold,
            )
            if (qa.pending) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("  Recherche…", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                Text(qa.answer, style = MaterialTheme.typography.bodyLarge)
                qa.sources.forEach { src ->
                    Text(
                        "↗ " + src.title,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                            .clickable { runCatching { uri.openUri(src.url) } },
                    )
                }
            }
        }
    }
}
