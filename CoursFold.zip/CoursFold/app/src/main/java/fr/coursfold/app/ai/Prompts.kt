package fr.coursfold.app.ai

/** Les consignes envoyées à l'IA. Tu peux les modifier pour changer le style des réponses. */
object Prompts {

    fun questionSystem(subject: String, level: String, withAudio: Boolean) = """
Tu aides un étudiant pendant un cours en direct (matière : $subject${if (level.isNotBlank()) ", niveau : $level" else ""}).
${if (withAudio) "On te donne l'enregistrement audio des 90 dernières secondes du cours : écoute-le attentivement. Une transcription automatique approximative est aussi fournie, mais l'audio fait foi."
  else "On te donne la transcription automatique des dernières minutes : elle contient des fautes de reconnaissance vocale et n'a pas de ponctuation."}
Ta tâche :
1. Repérer la DERNIÈRE question que le professeur pose à la classe (ou la question écrite par l'étudiant si elle est fournie).
2. Donner une réponse juste, courte et facile à dire à l'oral (2 à 4 phrases maximum), en français, au niveau du cours.
Réponds exactement sous ce format :
Question : <la question reformulée proprement>
Réponse : <la réponse>
S'il n'y a aucune question claire, écris seulement : Question : aucune question détectée
""".trimIndent()

    fun questionPrompt(recentTranscript: String, typedQuestion: String) = buildString {
        if (typedQuestion.isNotBlank()) {
            append("Question écrite par l'étudiant : ").append(typedQuestion).append("\n\n")
        }
        append("Transcription des dernières minutes du cours :\n\"\"\"\n")
        append(recentTranscript.ifBlank { "(rien pour l'instant)" })
        append("\n\"\"\"")
    }

    fun courseSystem(subject: String, level: String, withAudio: Boolean) = """
Tu es un excellent professeur de $subject${if (level.isNotBlank()) " (niveau $level)" else ""} qui prépare des supports de révision.
${if (withAudio) "On te donne l'enregistrement audio complet d'un cours oral (éventuellement en plusieurs morceaux, dans l'ordre). Écoute-le en entier : c'est la source principale. Une transcription automatique approximative est aussi fournie pour t'aider."
  else "On te donne la transcription automatique complète d'un cours oral : il y a des erreurs de reconnaissance vocale, des répétitions, des hésitations et des digressions."}
Corrige les mots mal compris d'après le contexte, sans inventer de contenu absent du cours. Si un point est incompréhensible, signale-le avec [passage peu clair].
Écris en français, en Markdown simple (titres #, ##, ###, listes à puces -, **gras**). N'utilise pas de tableaux.

Produis DEUX parties, séparées exactement par ces marqueurs, chacun seul sur sa ligne :

===RESUME===
Un résumé du cours en 10 lignes maximum : le sujet, les idées principales, ce qu'il faut absolument retenir.

===COURS===
Le cours rédigé proprement, prêt à servir de fiche de révision :
# <titre du cours>
Des parties et sous-parties logiques (## et ###), avec les définitions en **gras**, les formules, dates, exemples et méthodes donnés par le professeur.
Puis une section « ## À retenir » (points clés en liste),
une section « ## Questions du prof » (les questions posées en cours avec leur réponse, s'il y en a),
et une section « ## Teste-toi » avec 5 questions d'auto-évaluation suivies de leurs réponses.
""".trimIndent()

    fun coursePrompt(transcript: String, qas: String) = buildString {
        append("Transcription automatique du cours :\n\"\"\"\n")
        append(transcript.ifBlank { "(non disponible)" })
        append("\n\"\"\"")
        if (qas.isNotBlank()) {
            append("\n\nQuestions repérées pendant le cours et réponses trouvées :\n")
            append(qas)
        }
    }

    /** Coupe la réponse de l'IA en (résumé, cours). */
    fun splitCourse(text: String): Pair<String, String> {
        val r = text.indexOf("===RESUME===")
        val c = text.indexOf("===COURS===")
        return if (r >= 0 && c > r) {
            text.substring(r + 12, c).trim() to text.substring(c + 11).trim()
        } else if (c >= 0) {
            text.substring(0, c).replace("===RESUME===", "").trim() to text.substring(c + 11).trim()
        } else {
            "" to text.trim()
        }
    }

    /** Coupe « Question : … Réponse : … ». */
    fun splitAnswer(text: String): Pair<String, String> {
        val q = Regex("""Question\s*:\s*(.*)""", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)?.trim()
        val idx = text.indexOf("Réponse", ignoreCase = true)
        val a = if (idx >= 0) text.substring(idx).substringAfter(":").trim() else text.trim()
        return (q ?: "Question") to a
    }

    /** Petits indices qui montrent que le prof pose une question à la classe. */
    private val questionCues = listOf(
        "qui peut me dire", "qui sait", "quelqu'un sait", "quelqu'un peut", "qui a une idée",
        "vous savez", "à votre avis", "selon vous", "d'après vous", "qu'est-ce que c'est",
        "qu'est-ce qu'on", "qu'est-ce que vous", "est-ce que quelqu'un", "pourquoi à votre",
        "quelle est la réponse", "c'est quoi", "vous pouvez me dire", "qui veut répondre",
        "vous avez une idée", "vous vous souvenez", "comment on appelle",
    )

    fun looksLikeTeacherQuestion(segment: String): Boolean {
        val s = segment.lowercase().replace('’', '\'')
        return questionCues.any { s.contains(it) }
    }
}
