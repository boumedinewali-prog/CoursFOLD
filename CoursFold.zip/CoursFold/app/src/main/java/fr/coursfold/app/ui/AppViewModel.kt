package fr.coursfold.app.ui

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.coursfold.app.ai.AiException
import fr.coursfold.app.ai.GeminiClient
import fr.coursfold.app.ai.Prompts
import fr.coursfold.app.data.QA
import fr.coursfold.app.data.Segment
import fr.coursfold.app.data.Session
import fr.coursfold.app.data.SessionStore
import fr.coursfold.app.data.Settings
import fr.coursfold.app.speech.ContinuousRecognizer
import fr.coursfold.app.speech.VoskEngine
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Home : Screen
    data object Live : Screen
    data class Detail(val id: String) : Screen
    data object Settings : Screen
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val settings = Settings(app)
    private val store = SessionStore(app)
    private val ai = GeminiClient(
        apiKey = { settings.apiKey },
        model = { settings.model },
        fallbackModel = Settings.FALLBACK_MODEL,
        onModelChanged = { settings.model = it },
    )
    private val audioDir = File(app.filesDir, "audio").apply { mkdirs() }
    private fun audioFile(id: String) = File(audioDir, "$id.aac")

    // ----- État affiché à l'écran -----
    var screen by mutableStateOf<Screen>(if (settings.apiKey.isBlank()) Screen.Settings else Screen.Home)
        private set
    var sessions by mutableStateOf(store.list())
        private set
    var live by mutableStateOf<Session?>(null)
        private set
    var partial by mutableStateOf("")
        private set
    var status by mutableStateOf("")
        private set
    var recording by mutableStateOf(false)
        private set
    var elapsedMs by mutableStateOf(0L)
        private set
    var generatingId by mutableStateOf<String?>(null)
        private set
    /** Étape en cours pendant la rédaction du cours (envoi de l'audio, rédaction…). */
    var generatingStep by mutableStateOf("")
        private set
    var message by mutableStateOf<String?>(null)
    /** Progression du téléchargement du modèle vocal (null = pas de téléchargement). */
    var modelProgress by mutableStateOf<Float?>(null)
        private set
    private var preparing = false

    // ----- Chronomètre -----
    private var accumulatedMs = 0L
    private var runningSince = 0L
    private var tickJob: Job? = null
    private var lastAutoQuestionAt = -60_000L

    private fun now(): Long =
        accumulatedMs + if (recording) SystemClock.elapsedRealtime() - runningSince else 0

    private val recognizer = ContinuousRecognizer(
        context = app,
        onPartial = { partial = it },
        onFinal = ::onFinalText,
        onStatus = { status = it },
        onFatal = { msg ->
            message = msg
            pauseRecording()
        },
    )

    private val vosk = VoskEngine(app)
    private val useVosk get() = settings.engine == "vosk"

    // ----- Navigation -----
    fun open(s: Screen) {
        screen = s
    }

    fun back() {
        screen = when (screen) {
            is Screen.Live -> Screen.Live // on ne quitte pas un cours par erreur : bouton « Terminer »
            else -> Screen.Home
        }
    }

    fun session(id: String): Session? =
        if (live?.id == id) live else sessions.firstOrNull { it.id == id }

    // ----- Enregistrement d'un cours -----
    fun startCourse(subject: String) {
        val name = subject.trim().ifEmpty { "Cours" }
        settings.lastSubject = name
        live = Session(id = System.currentTimeMillis().toString(), subject = name, startedAt = System.currentTimeMillis())
        accumulatedMs = 0
        lastAutoQuestionAt = -60_000L
        elapsedMs = 0
        screen = Screen.Live
        resumeRecording()
    }

    fun resumeRecording() {
        if (recording || preparing || live == null) return
        if (!useVosk) {
            recognizer.muteBeeps = settings.muteBeeps
            recognizer.start()
            if (recognizer.isRunning) startClock()
            return
        }
        preparing = true
        viewModelScope.launch {
            try {
                if (!vosk.isModelReady) {
                    status = "Téléchargement du modèle vocal français (41 Mo, une seule fois)…"
                    modelProgress = 0f
                    vosk.downloadModel { p -> viewModelScope.launch { modelProgress = p } }
                    modelProgress = null
                }
                status = "Chargement du modèle vocal…"
                vosk.load()
                val current = live ?: return@launch
                vosk.start(
                    audioFile = audioFile(current.id),
                    onPartial = { partial = it },
                    onFinal = ::onFinalText,
                    onError = { msg -> message = msg; pauseRecording() },
                )
                if (!vosk.isListening) return@launch
                status = "Écoute continue (hors ligne)"
                startClock()
            } catch (e: Exception) {
                modelProgress = null
                status = "En pause"
                message = "Modèle vocal : ${e.message ?: "erreur"}. Vérifie ta connexion et réessaie (▶)."
            } finally {
                preparing = false
            }
        }
    }

    private fun startClock() {
        runningSince = SystemClock.elapsedRealtime()
        recording = true
        tickJob?.cancel()
        tickJob = viewModelScope.launch {
            while (isActive) {
                elapsedMs = now()
                delay(1000)
            }
        }
    }

    fun pauseRecording() {
        if (!recording) return
        accumulatedMs = now()
        recording = false
        recognizer.stop()
        vosk.stop()
        tickJob?.cancel()
        elapsedMs = accumulatedMs
        status = "En pause"
        saveLive()
    }

    fun finishCourse() {
        pauseRecording()
        val s = live ?: return
        val leftover = partial.trim()
        val finished = s.copy(
            durationMs = accumulatedMs,
            segments = if (leftover.isNotEmpty()) s.segments + Segment(accumulatedMs, leftover) else s.segments,
            qas = s.qas.filter { !it.pending },
        )
        partial = ""
        live = null
        val audio = audioFile(finished.id)
        if (finished.segments.isEmpty() && (!audio.exists() || audio.length() < 20_000)) {
            audio.delete()
            message = "Rien n'a été transcrit, le cours n'est pas enregistré."
            screen = Screen.Home
            return
        }
        store.save(finished)
        sessions = store.list()
        screen = Screen.Detail(finished.id)
        generateCourse(finished.id)
    }

    private fun onFinalText(text: String) {
        val s = live ?: return
        live = s.copy(segments = s.segments + Segment(now(), text))
        saveLive()
        if (settings.autoQuestions && Prompts.looksLikeTeacherQuestion(text) &&
            now() - lastAutoQuestionAt > 45_000
        ) {
            lastAutoQuestionAt = now()
            // On attend quelques secondes pour avoir la fin de la question.
            viewModelScope.launch {
                delay(4000)
                askQuestion("")
            }
        }
    }

    private fun saveLive() {
        live?.let { store.save(it.copy(durationMs = now())) }
    }

    // ----- Recherche en direct -----
    fun askQuestion(typed: String) {
        val s = live ?: return
        val at = now()
        val pendingQa = QA(atMs = at, question = typed.ifBlank { "Recherche de la question…" }, answer = "", pending = true)
        live = s.copy(qas = listOf(pendingQa) + s.qas)

        val recent = recentTranscript(s, at)
        // Le vrai son des 90 dernières secondes : bien plus fiable que la transcription en direct.
        val wav = if (useVosk && recording) vosk.recentWav() else null
        viewModelScope.launch {
            val done = try {
                val parts = buildList {
                    if (wav != null) add(ai.inlineAudioPart(wav, "audio/wav"))
                    add(ai.textPart(Prompts.questionPrompt(recent, typed)))
                }
                val r = ai.generate(
                    system = Prompts.questionSystem(s.subject, settings.level, withAudio = wav != null),
                    parts = parts,
                    webSearch = settings.webSearch,
                )
                val (q, a) = Prompts.splitAnswer(r.text)
                QA(atMs = at, question = q, answer = a, sources = r.sources)
            } catch (e: AiException) {
                QA(atMs = at, question = typed.ifBlank { "Question" }, answer = e.message ?: "Erreur", error = true)
            } catch (e: Exception) {
                QA(atMs = at, question = typed.ifBlank { "Question" }, answer = "Erreur : ${e.message}", error = true)
            }
            val cur = live ?: return@launch
            live = cur.copy(qas = cur.qas.map { if (it.pending && it.atMs == at) done else it })
            saveLive()
        }
    }

    /** Les ~2 dernières minutes de texte (et au plus 4000 caractères). */
    private fun recentTranscript(s: Session, at: Long): String {
        val recent = s.segments.filter { it.atMs >= at - 150_000 }
            .ifEmpty { s.segments.takeLast(8) }
            .joinToString(" ") { it.text }
        val withPartial = (recent + " " + partial).trim()
        return withPartial.takeLast(4000)
    }

    // ----- Résumé + cours propre -----
    fun generateCourse(id: String) {
        val s = session(id) ?: return
        if (generatingId != null) {
            message = "Une génération est déjà en cours."
            return
        }
        generatingId = id
        viewModelScope.launch {
            try {
                val qas = s.qas.filter { !it.error }.joinToString("\n") { "- ${it.question} → ${it.answer}" }
                val audio = audioFile(id)
                val audioUri: String? = if (audio.exists() && audio.length() > 20_000) {
                    try {
                        generatingStep = "Envoi de l'audio du cours (${audio.length() / 1_000_000 + 1} Mo)…"
                        ai.uploadFile(audio, "audio/aac") { p ->
                            viewModelScope.launch { generatingStep = "Envoi de l'audio du cours… ${(p * 100).toInt()} %" }
                        }
                    } catch (e: AiException) {
                        message = "Audio non envoyé (${e.message}). Cours rédigé à partir du texte en direct."
                        null
                    }
                } else null
                generatingStep = if (audioUri != null) "Gemini écoute le cours et le rédige… (1 à 3 min)"
                                 else "Rédaction du cours… (jusqu'à une minute)"
                val parts = buildList {
                    if (audioUri != null) add(ai.fileAudioPart(audioUri, "audio/aac"))
                    add(ai.textPart(Prompts.coursePrompt(s.fullText, qas)))
                }
                val r = ai.generate(
                    system = Prompts.courseSystem(s.subject, settings.level, withAudio = audioUri != null),
                    parts = parts,
                    webSearch = false, // pas besoin d'internet ici : on économise le quota
                    temperature = 0.2,
                    timeoutMs = 420_000,
                )
                val (summary, course) = Prompts.splitCourse(r.text)
                val latest = session(id) ?: s
                val updated = latest.copy(summary = summary, course = course)
                store.save(updated)
                sessions = store.list()
            } catch (e: AiException) {
                message = e.message
            } catch (e: Exception) {
                message = "Erreur : ${e.message}"
            } finally {
                generatingId = null
                generatingStep = ""
            }
        }
    }

    fun deleteSession(id: String) {
        store.delete(id)
        audioFile(id).delete()
        sessions = store.list()
        if (screen == Screen.Detail(id)) screen = Screen.Home
    }

    fun saveSettings(apiKey: String, model: String, level: String, auto: Boolean, web: Boolean, mute: Boolean, engine: String) {
        settings.engine = engine
        settings.apiKey = apiKey
        settings.model = model
        settings.level = level
        settings.autoQuestions = auto
        settings.webSearch = web
        settings.muteBeeps = mute
        message = "Réglages enregistrés"
        screen = Screen.Home
    }

    fun exportText(id: String): String {
        val s = session(id) ?: return ""
        return buildString {
            if (s.course.isNotBlank()) append(s.course).append("\n\n")
            if (s.summary.isNotBlank()) append("## Résumé\n").append(s.summary).append("\n\n")
            if (s.course.isBlank()) append("## Transcription\n").append(s.fullText)
        }.trim()
    }

    override fun onCleared() {
        recognizer.stop()
        vosk.stop()
        super.onCleared()
    }
}
