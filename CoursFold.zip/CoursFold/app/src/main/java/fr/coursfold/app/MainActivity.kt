package fr.coursfold.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import fr.coursfold.app.ui.AppViewModel
import fr.coursfold.app.ui.CoursTheme
import fr.coursfold.app.ui.DetailScreen
import fr.coursfold.app.ui.HomeScreen
import fr.coursfold.app.ui.LiveScreen
import fr.coursfold.app.ui.Screen
import fr.coursfold.app.ui.SettingsScreen
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CoursTheme {
                var pendingSubject by remember { mutableStateOf<String?>(null) }
                val micPermission = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { granted ->
                    val subject = pendingSubject
                    pendingSubject = null
                    if (granted && subject != null) vm.startCourse(subject)
                    else if (!granted) vm.message = "Sans accès au micro, l'appli ne peut pas transcrire le cours."
                }

                val startCourse: (String) -> Unit = { subject ->
                    when {
                        vm.settings.apiKey.isBlank() -> {
                            vm.message = "Ajoute d'abord ta clé Gemini gratuite."
                            vm.open(Screen.Settings)
                        }
                        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                            PackageManager.PERMISSION_GRANTED -> vm.startCourse(subject)
                        else -> {
                            pendingSubject = subject
                            micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                }

                BackHandler(enabled = vm.screen != Screen.Home) { vm.back() }

                Surface(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize()) {
                        when (val s = vm.screen) {
                            Screen.Home -> HomeScreen(vm, startCourse)
                            Screen.Live -> LiveScreen(vm)
                            Screen.Settings -> SettingsScreen(vm)
                            is Screen.Detail -> DetailScreen(vm, s.id)
                        }

                        val msg = vm.message
                        if (msg != null) {
                            LaunchedEffect(msg) {
                                delay(4500)
                                vm.message = null
                            }
                            Snackbar(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .navigationBarsPadding()
                                    .padding(16.dp),
                            ) { Text(msg) }
                        }
                    }
                }
            }
        }
    }
}
