package fr.coursfold.app.speech

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Reconnaissance vocale continue avec Vosk : 100 % hors ligne, gratuite,
 * et surtout elle écoute sans jamais s'arrêter (aucun morceau perdu entre deux phrases).
 * Le modèle français (~41 Mo) est téléchargé une seule fois au premier cours.
 */
class VoskEngine(private val context: Context) {

    private val modelDir = File(context.filesDir, "vosk-fr")
    private var model: Model? = null
    private var recorder: CourseRecorder? = null

    val isListening: Boolean get() = recorder != null

    val isModelReady: Boolean get() = File(modelDir, "conf/model.conf").exists() || File(modelDir, "am").exists()

    /** Télécharge et décompresse le modèle français. [onProgress] reçoit 0..1. */
    suspend fun downloadModel(onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val tmpZip = File(context.cacheDir, "vosk-fr.zip")
        val tmpDir = File(context.filesDir, "vosk-fr.tmp")
        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) throw Exception("Téléchargement impossible (code ${conn.responseCode}).")
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: 41_000_000L
            conn.inputStream.use { input ->
                tmpZip.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var lastReport = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (done - lastReport > 500_000) {
                            lastReport = done
                            onProgress((done.toFloat() / total).coerceIn(0f, 0.95f))
                        }
                    }
                }
            }
        } finally {
            conn.disconnect()
        }

        // Décompression (on enlève le dossier racine du zip).
        tmpDir.deleteRecursively()
        tmpDir.mkdirs()
        ZipInputStream(tmpZip.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val rel = entry.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val out = File(tmpDir, rel)
                if (!out.canonicalPath.startsWith(tmpDir.canonicalPath)) continue
                if (entry.isDirectory) out.mkdirs()
                else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zip.copyTo(it) }
                }
            }
        }
        tmpZip.delete()
        modelDir.deleteRecursively()
        if (!tmpDir.renameTo(modelDir)) throw Exception("Impossible d'installer le modèle.")
        onProgress(1f)
    }

    /** Charge le modèle en mémoire (quelques secondes la première fois). */
    suspend fun load() = withContext(Dispatchers.IO) {
        if (model == null) {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            model = Model(modelDir.absolutePath)
        }
    }

    /**
     * Démarre l'écoute et l'enregistrement du cours dans [audioFile] (complété à chaque reprise).
     * Doit être appelé après [load]. Callbacks sur le thread principal.
     */
    fun start(
        audioFile: File,
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onError: (String) -> Unit,
    ) {
        val m = model ?: run { onError("Modèle vocal non chargé."); return }
        stop()
        val r = CourseRecorder(m, audioFile, onPartial, onFinal, onError)
        if (r.start()) recorder = r
    }

    /** Les dernières secondes de son (WAV), ou null si on n'enregistre pas. */
    fun recentWav(): ByteArray? = recorder?.recentWav()

    fun stop() {
        recorder?.stop()
        recorder = null
    }

    private fun field(json: String?, key: String): String =
        runCatching { JSONObject(json ?: "{}").optString(key) }.getOrDefault("").trim()

    companion object {
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip"
    }
}
