package fr.coursfold.app.data

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Sauvegarde chaque cours dans un fichier JSON, sur le téléphone uniquement. */
class SessionStore(context: Context) {
    private val dir = File(context.filesDir, "sessions").apply { mkdirs() }

    fun save(session: Session) {
        val tmp = File(dir, "${session.id}.json.tmp")
        tmp.writeText(session.toJson().toString())
        tmp.renameTo(File(dir, "${session.id}.json"))
    }

    fun load(id: String): Session? = runCatching {
        Session.fromJson(JSONObject(File(dir, "$id.json").readText()))
    }.getOrNull()

    fun list(): List<Session> = (dir.listFiles() ?: emptyArray())
        .filter { it.name.endsWith(".json") }
        .mapNotNull { f -> runCatching { Session.fromJson(JSONObject(f.readText())) }.getOrNull() }
        .sortedByDescending { it.startedAt }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }
}

/** Réglages de l'appli (clé API, modèle, options). */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("apiKey", "") ?: ""
        set(v) = prefs.edit().putString("apiKey", v.trim()).apply()

    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = prefs.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    var level: String
        get() = prefs.getString("level", "") ?: ""
        set(v) = prefs.edit().putString("level", v.trim()).apply()

    var autoQuestions: Boolean
        get() = prefs.getBoolean("autoQuestions", false)
        set(v) = prefs.edit().putBoolean("autoQuestions", v).apply()

    var webSearch: Boolean
        get() = prefs.getBoolean("webSearch", true)
        set(v) = prefs.edit().putBoolean("webSearch", v).apply()

    var muteBeeps: Boolean
        get() = prefs.getBoolean("muteBeeps", true)
        set(v) = prefs.edit().putBoolean("muteBeeps", v).apply()

    /** "vosk" = continu hors ligne (recommandé), "google" = moteur vocal d'Android. */
    var engine: String
        get() = prefs.getString("engine", "vosk") ?: "vosk"
        set(v) = prefs.edit().putString("engine", v).apply()

    var lastSubject: String
        get() = prefs.getString("lastSubject", "") ?: ""
        set(v) = prefs.edit().putString("lastSubject", v).apply()

    companion object {
        // Modèle par défaut : offre gratuite + recherche Google gratuite (quota quotidien).
        const val DEFAULT_MODEL = "gemini-2.5-flash"
        const val FALLBACK_MODEL = "gemini-2.5-flash-lite"
    }
}
