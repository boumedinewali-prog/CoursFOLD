# CoursFold

Appli Android pour Galaxy Z Fold : transcrit le cours en direct, répond aux questions du prof dans un panneau à côté, et rédige à la fin un résumé et un cours propre pour tes fiches de révision. Tout est gratuit.

## Ce que fait l'appli

- **Transcription en direct, gratuite** : faite par le téléphone (reconnaissance vocale Android, hors ligne si le pack français est installé).
- **Panneau de réponse** : touche « Le prof pose une question » et l'appli repère la question dans les deux dernières minutes, cherche sur Google et affiche une réponse courte avec ses sources. Tu peux aussi écrire ta propre question. Une option détecte les questions toute seule.
- **Fin de cours** : « Terminer » → résumé + cours rédigé proprement (titres, définitions en gras, « À retenir », « Teste-toi »), que tu peux copier ou envoyer vers Samsung Notes, Google Docs, etc.
- **Fold ouvert** : transcription à gauche, réponses à droite. **Fold fermé** : l'un au-dessus de l'autre.
- Les cours restent stockés sur le téléphone. Seul le texte part vers Gemini quand tu demandes une réponse ou un cours.

## 1. Obtenir l'APK (sans ordinateur)

Le projet contient une compilation automatique sur GitHub (gratuite) :

1. Mets ce dossier dans un dépôt GitHub (branche `main`).
2. GitHub compile tout seul (onglet **Actions**, ~5 min).
3. Sur ton Fold, ouvre la page **Releases** du dépôt → touche **CoursFold.apk**.
4. Autorise l'installation depuis ton navigateur quand Android le demande, puis installe.

À chaque modification du code, une nouvelle version est publiée au même endroit et s'installe par-dessus l'ancienne sans effacer tes cours.

*Avec un ordinateur* : ouvre le dossier dans Android Studio, branche le Fold (débogage USB activé) et appuie sur ▶.

## 2. Première ouverture

1. L'appli s'ouvre sur les **réglages** : touche « Ouvrir Google AI Studio », connecte-toi avec ton compte Google, **Create API key**, copie la clé et colle-la.
2. Indique ton niveau (ex. « Terminale », « L2 éco ») pour des réponses adaptées.
3. Pour une transcription hors ligne et plus stable : Paramètres du téléphone → Gestion globale → Langue → Reconnaissance vocale (ou Google → Reconnaissance vocale hors connexion) → télécharge **Français**.

## Bon à savoir

- **Garde l'appli ouverte** pendant le cours (l'écran reste allumé tout seul). Android coupe le micro des applis en arrière-plan.
- Le quota gratuit de Gemini est limité chaque jour : la transcription ne le consomme pas, seules les questions et la génération du cours en utilisent. Laisse la détection automatique désactivée si tu tombes souvent sur « quota atteint ».
- Avec l'offre gratuite, Google peut utiliser le texte envoyé pour améliorer ses services.
- Demande l'accord de tes profs avant d'enregistrer : beaucoup d'établissements l'exigent.
- Android relance l'écoute à chaque pause du prof : il peut manquer un mot de temps en temps.

## Organisation du code

| Fichier | Rôle |
|---|---|
| `speech/ContinuousRecognizer.kt` | Écoute continue du micro |
| `ai/GeminiClient.kt` | Appels à Gemini (+ recherche Google) |
| `ai/Prompts.kt` | Consignes données à l'IA — à modifier pour changer le style des fiches |
| `ui/AppViewModel.kt` | Logique de l'appli |
| `ui/LiveScreen.kt` | Écran pendant le cours |
| `ui/DetailScreen.kt` | Cours terminé : cours propre, résumé, questions, transcription |
| `ui/HomeAndSettings.kt` | Accueil et réglages |
